#include "hero.h"
#include<QPoint>
#include<QPixmap>
#include <QPainter>
hero::hero(QPoint pos, QString pix):QObject(0),pixmap(pix){
    _pos=pos;

}
void hero::draw(QPainter *painter){
    painter->drawPixmap(_pos,pixmap);
}
