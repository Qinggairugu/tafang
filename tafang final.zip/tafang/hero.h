#ifndef HERO_H
#define HERO_H

#include <QObject>
#include<QPoint>
#include<QPixmap>
#include<QPainter>
#include"wugong.h"
#include<QList>
class hero : public QObject
{
    Q_OBJECT
public:
    hero(QPoint pos,QString pix);
    void draw(QPainter *painter);
    QPoint getpos(){return this->_pos;}

private:
    QPoint _pos;
    QPixmap pixmap;


signals:

public slots:
};

#endif // HERO_H
