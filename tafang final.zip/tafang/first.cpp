#include "first.h"
#include"button.h"
#include<QPainter>
#include<QPoint>
#include<QPixmap>
#include<QTimer>
#include<QTime>
#include<math.h>
#include<QCoreApplication>
#include<QDebug>
#include<QMediaPlayer>
first::first(QWidget *parent) : QMainWindow(parent)
{
    this->setFixedSize(960,640);
    button *huangyaohsi=new button("://huangyaoshibt.png");
    huangyaohsi->setParent(this);
    huangyaohsi->move(330,530);
    button *xiaolongnv=new button("://xiaolongnvbt.png");
    xiaolongnv->setParent(this);
    xiaolongnv->move(440,530);
    button *guojing = new button("://guojingbt.png");
    guojing->setParent(this);
    guojing->move(230,530);
    button *shoubing = new button("://shoubing.png");
    shoubing->setParent(this);
    shoubing->move(540,530);
    button *_restart = new button("://restart.png");
    _restart->setParent(this);
    _restart->move(20,530);
//����Ӣ��,�Ƴ��������¿�ʼ��
    QPushButton *setHero1_1= new QPushButton;
    setHero1_1->setParent(this);
    setHero1_1->setFixedSize(60,60);
    setHero1_1->setFlat(true);
    setHero1_1->move(30,30);
    QPushButton *setHero2_1= new QPushButton;
    setHero2_1->setParent(this);
    setHero2_1->setFixedSize(60,60);
    setHero2_1->setFlat(true);
    setHero2_1->move(30,150);
    QPushButton *setHero3_1= new QPushButton;
    setHero3_1->setParent(this);
    setHero3_1->setFixedSize(60,60);
    setHero3_1->setFlat(true);
    setHero3_1->move(30,280);
    QPushButton *setHero4_1= new QPushButton;
    setHero4_1->setParent(this);
    setHero4_1->setFixedSize(60,60);
    setHero4_1->setFlat(true);
    setHero4_1->move(30,410);
    QPushButton *setHero1_2= new QPushButton;
    setHero1_2->setParent(this);
    setHero1_2->setFixedSize(60,60);
    setHero1_2->setFlat(true);
    setHero1_2->move(130,30);
    QPushButton *setHero2_2= new QPushButton;
    setHero2_2->setParent(this);
    setHero2_2->setFixedSize(60,60);
    setHero2_2->setFlat(true);
    setHero2_2->move(130,150);
    QPushButton *setHero3_2= new QPushButton;
    setHero3_2->setParent(this);
    setHero3_2->setFixedSize(60,60);
    setHero3_2->setFlat(true);
    setHero3_2->move(130,280);
    QPushButton *setHero4_2= new QPushButton;
    setHero4_2->setParent(this);
    setHero4_2->setFixedSize(60,60);
    setHero4_2->setFlat(true);
    setHero4_2->move(130,410);
    QPushButton *setHero1_3= new QPushButton;
    setHero1_3->setParent(this);
    setHero1_3->setFixedSize(60,60);
    setHero1_3->setFlat(true);
    setHero1_3->move(235,30);
    QPushButton *setHero2_3= new QPushButton;
    setHero2_3->setParent(this);
    setHero2_3->setFixedSize(60,60);
    setHero2_3->setFlat(true);
    setHero2_3->move(235,150);
    QPushButton *setHero3_3= new QPushButton;
    setHero3_3->setParent(this);
    setHero3_3->setFixedSize(60,60);
    setHero3_3->setFlat(true);
    setHero3_3->move(235,280);
    QPushButton *setHero4_3= new QPushButton;
    setHero4_3->setParent(this);
    setHero4_3->setFixedSize(60,60);
    setHero4_3->setFlat(true);
    setHero4_3->move(235,410);
    QPushButton *setHero1_4= new QPushButton;
    setHero1_4->setParent(this);
    setHero1_4->setFixedSize(60,60);
    setHero1_4->setFlat(true);
    setHero1_4->move(340,30);
    QPushButton *setHero2_4= new QPushButton;
    setHero2_4->setParent(this);
    setHero2_4->setFixedSize(60,60);
    setHero2_4->setFlat(true);
    setHero2_4->move(340,150);
    QPushButton *setHero3_4= new QPushButton;
    setHero3_4->setParent(this);
    setHero3_4->setFixedSize(60,60);
    setHero3_4->setFlat(true);
    setHero3_4->move(340,280);
    QPushButton *setHero4_4= new QPushButton;
    setHero4_4->setParent(this);
    setHero4_4->setFixedSize(60,60);
    setHero4_4->setFlat(true);
    setHero4_4->move(340,410);
    QPushButton *setHero1_5= new QPushButton;
    setHero1_5->setParent(this);
    setHero1_5->setFixedSize(60,60);
    setHero1_5->setFlat(true);
    setHero1_5->move(450,30);
    QPushButton *setHero2_5= new QPushButton;
    setHero2_5->setParent(this);
    setHero2_5->setFixedSize(60,60);
    setHero2_5->setFlat(true);
    setHero2_5->move(450,150);
    QPushButton *setHero3_5= new QPushButton;
    setHero3_5->setParent(this);
    setHero3_5->setFixedSize(50,50);
    setHero3_5->setFlat(true);
    setHero3_5->move(450,280);
    QPushButton *setHero4_5= new QPushButton;
    setHero4_5->setParent(this);
    setHero4_5->setFixedSize(60,60);
    setHero4_5->setFlat(true);
    setHero4_5->move(450,410);
//����Ӣ�۵�λ��
    button *jingong= new button(":/button3.png");
    jingong->setParent(this);
    jingong->move(800,530);
//������ť

    connect(guojing,&button::clicked,this,[=](){
        F=1;
        qDebug()<<F;

        guojing->down();
        guojing->up();
        });
    //����
    connect(xiaolongnv,&button::clicked,this,[=](){
        F=2;
        qDebug()<<F;
        xiaolongnv->down();
        xiaolongnv->up();
    });
    //С��Ů
    connect(huangyaohsi,&button::clicked,this,[=](){
        F=3;
        huangyaohsi->down();
        huangyaohsi->up();
    });
    //��ҩʦ
//�Ƴ�Ӣ�ۼ��书
    connect(shoubing,&button::clicked,this,[=](){
       shoubing->down();
       shoubing->up();
       F=-1;
       setHero1_1->setEnabled(true);
       setHero2_1->setEnabled(true);
       setHero3_1->setEnabled(true);
       setHero4_1->setEnabled(true);
       setHero1_2->setEnabled(true);
       setHero2_2->setEnabled(true);
       setHero3_2->setEnabled(true);
       setHero4_2->setEnabled(true);
       setHero1_3->setEnabled(true);
       setHero2_3->setEnabled(true);
       setHero3_3->setEnabled(true);
       setHero4_3->setEnabled(true);
       setHero1_4->setEnabled(true);
       setHero2_4->setEnabled(true);
       setHero3_4->setEnabled(true);
       setHero4_4->setEnabled(true);
       setHero1_5->setEnabled(true);
       setHero2_5->setEnabled(true);
       setHero3_5->setEnabled(true);
       setHero4_5->setEnabled(true);

    });
    connect(setHero1_1,&button::clicked,this,[=](){
        if(F==1&&money>=80){
            QPoint a=setHero1_1->pos();
            first::set_hero1(a);
            first::setwugong1(a,1,1);
            setHero1_1->setEnabled(false);
            money-=80;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero1_1->pos();
            first::set_hero2(a);
            first::setwugong2(a,1,1);
            setHero1_1->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero1_1->pos();
            first::set_hero3(a);
            first::setwugong3(a,1,1);
            setHero1_1->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero1_1->x()&&a->getpos().y()==setHero1_1->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero1_1->x()&&b->getstartpos().y()==setHero1_1->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero1_1->x()&&c->getstartpos().y()==setHero1_1->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;


    });
    connect(setHero2_1,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero2_1->pos();
            first::set_hero1(a);
            first::setwugong1(a,2,1);
            setHero2_1->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero2_1->pos();
            first::set_hero2(a);
            first::setwugong2(a,2,1);
            setHero2_1->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero2_1->pos();
            first::set_hero3(a);
            first::setwugong3(a,2,1);
            setHero2_1->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero2_1->x()&&a->getpos().y()==setHero2_1->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero2_1->x()&&b->getstartpos().y()==setHero2_1->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero2_1->x()&&c->getstartpos().y()==setHero2_1->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero3_1,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero3_1->pos();
            first::set_hero1(a);
            first::setwugong1(a,3,1);
            setHero3_1->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero3_1->pos();
            first::set_hero2(a);
            first::setwugong2(a,3,1);
            setHero3_1->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero3_1->pos();
            first::set_hero3(a);
            first::setwugong3(a,3,1);
            setHero3_1->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero3_1->x()&&a->getpos().y()==setHero3_1->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero3_1->x()&&b->getstartpos().y()==setHero3_1->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero3_1->x()&&c->getstartpos().y()==setHero3_1->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero4_1,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero4_1->pos();
            first::set_hero1(a);
            first::setwugong1(a,4,1);
            setHero4_1->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero4_1->pos();
            first::set_hero2(a);
            first::setwugong2(a,4,1);
            setHero4_1->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero4_1->pos();
            first::set_hero3(a);
            first::setwugong3(a,4,1);
            setHero4_1->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero4_1->x()&&a->getpos().y()==setHero4_1->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero4_1->x()&&b->getstartpos().y()==setHero4_1->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero4_1->x()&&c->getstartpos().y()==setHero4_1->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero1_2,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero1_2->pos();
            first::set_hero1(a);
            first::setwugong1(a,1,2);
            setHero1_2->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero1_2->pos();
            first::set_hero2(a);
            first::setwugong2(a,1,2);
            setHero1_2->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero1_2->pos();
            first::set_hero3(a);
            first::setwugong3(a,1,2);
            setHero1_2->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero1_2->x()&&a->getpos().y()==setHero1_2->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero1_2->x()&&b->getstartpos().y()==setHero1_2->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero1_2->x()&&c->getstartpos().y()==setHero1_2->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero2_2,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero2_2->pos();
            first::set_hero1(a);
            first::setwugong1(a,2,2);
            setHero2_2->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero2_2->pos();
            first::set_hero2(a);
            first::setwugong2(a,2,2);
            setHero2_2->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero2_2->pos();
            first::set_hero3(a);
            first::setwugong3(a,2,2);
            setHero2_2->setEnabled(false);
            money-=120;
        }
        else if(F==-1&&money>=80){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero2_2->x()&&a->getpos().y()==setHero2_2->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero2_2->x()&&b->getstartpos().y()==setHero2_2->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero2_2->x()&&c->getstartpos().y()==setHero2_2->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero3_2,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero3_2->pos();
            first::set_hero1(a);
            first::setwugong1(a,3,2);
            setHero3_2->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero3_2->pos();
            first::set_hero2(a);
            first::setwugong2(a,3,2);
            setHero3_2->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero3_2->pos();
            first::set_hero3(a);
            first::setwugong3(a,3,2);
            setHero3_2->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero3_2->x()&&a->getpos().y()==setHero3_2->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero3_2->x()&&b->getstartpos().y()==setHero3_2->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero3_2->x()&&c->getstartpos().y()==setHero3_2->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero4_2,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero4_2->pos();
            first::set_hero1(a);
            first::setwugong1(a,4,2);
            setHero4_2->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero4_2->pos();
            first::set_hero2(a);
            first::setwugong2(a,4,2);
            setHero4_2->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero4_2->pos();
            first::set_hero3(a);
            first::setwugong3(a,4,2);
            setHero4_2->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero4_2->x()&&a->getpos().y()==setHero4_2->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero4_2->x()&&b->getstartpos().y()==setHero4_2->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero4_2->x()&&c->getstartpos().y()==setHero4_2->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;
    });
    connect(setHero1_3,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero1_3->pos();
            first::set_hero1(a);
            first::setwugong1(a,1,3);
            setHero1_3->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero1_3->pos();
            first::set_hero2(a);
            first::setwugong2(a,1,3);
            setHero1_3->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero1_3->pos();
            first::set_hero3(a);
            first::setwugong3(a,1,3);
            setHero1_3->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero1_3->x()&&a->getpos().y()==setHero1_3->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero1_3->x()&&b->getstartpos().y()==setHero1_3->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero1_3->x()&&c->getstartpos().y()==setHero1_3->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero2_3,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero2_3->pos();
            first::set_hero1(a);
            first::setwugong1(a,2,3);
            setHero2_3->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero2_3->pos();
            first::set_hero2(a);
            first::setwugong2(a,2,3);
            setHero2_3->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero2_3->pos();
            first::set_hero3(a);
            first::setwugong3(a,2,3);
            setHero2_3->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero2_3->x()&&a->getpos().y()==setHero2_3->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero2_3->x()&&b->getstartpos().y()==setHero2_3->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero2_3->x()&&c->getstartpos().y()==setHero2_3->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;
    });
    connect(setHero3_3,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero3_3->pos();
            first::set_hero1(a);
            first::setwugong1(a,3,3);
            setHero3_3->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero3_3->pos();
            first::set_hero2(a);
            first::setwugong2(a,3,3);
            setHero3_3->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero3_3->pos();
            first::set_hero3(a);
            first::setwugong3(a,3,3);
            setHero3_3->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero3_3->x()&&a->getpos().y()==setHero3_3->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero3_3->x()&&b->getstartpos().y()==setHero3_3->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero3_3->x()&&c->getstartpos().y()==setHero3_3->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero4_3,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero4_3->pos();
            first::set_hero1(a);
            first::setwugong1(a,4,3);
            setHero4_3->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero4_3->pos();
            first::set_hero2(a);
            first::setwugong2(a,4,3);
            setHero4_3->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero4_3->pos();
            first::set_hero3(a);
            first::setwugong3(a,4,3);
            setHero4_3->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero4_3->x()&&a->getpos().y()==setHero4_3->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero4_3->x()&&b->getstartpos().y()==setHero4_3->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero4_3->x()&&c->getstartpos().y()==setHero4_3->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero1_4,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero1_4->pos();
            first::set_hero1(a);
            first::setwugong1(a,1,4);
            setHero1_4->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero1_4->pos();
            first::set_hero2(a);
            first::setwugong2(a,1,4);
            setHero1_4->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero1_4->pos();
            first::set_hero3(a);
            first::setwugong3(a,1,4);
            setHero1_4->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero1_4->x()&&a->getpos().y()==setHero1_4->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero1_4->x()&&b->getstartpos().y()==setHero1_4->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero1_4->x()&&c->getstartpos().y()==setHero1_4->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;


    });
    connect(setHero2_4,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero2_4->pos();
            first::set_hero1(a);
            first::setwugong1(a,2,4);
            setHero2_4->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero2_4->pos();
            first::set_hero2(a);
            first::setwugong2(a,2,4);
            setHero2_4->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero2_4->pos();
            first::set_hero3(a);
            first::setwugong3(a,2,4);
            setHero2_4->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero2_4->x()&&a->getpos().y()==setHero2_4->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero2_4->x()&&b->getstartpos().y()==setHero2_4->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero2_4->x()&&c->getstartpos().y()==setHero2_4->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;


    });
    connect(setHero3_4,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero3_4->pos();
            first::set_hero1(a);
            first::setwugong1(a,3,4);
            setHero3_4->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero3_4->pos();
            first::set_hero2(a);
            first::setwugong2(a,3,4);
            setHero3_4->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero3_4->pos();
            first::set_hero3(a);
            first::setwugong3(a,3,4);
            setHero3_4->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero3_4->x()&&a->getpos().y()==setHero3_4->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero3_4->x()&&b->getstartpos().y()==setHero3_4->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero3_4->x()&&c->getstartpos().y()==setHero3_4->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero4_4,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero4_4->pos();
            first::set_hero1(a);
            first::setwugong1(a,4,4);
            setHero4_4->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero4_4->pos();
            first::set_hero2(a);
            first::setwugong2(a,4,4);
            setHero4_4->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero4_4->pos();
            first::set_hero3(a);
            first::setwugong3(a,4,4);
            setHero4_4->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero4_4->x()&&a->getpos().y()==setHero4_4->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero4_4->x()&&b->getstartpos().y()==setHero4_4->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero4_4->x()&&c->getstartpos().y()==setHero4_4->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero1_5,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero1_5->pos();
            first::set_hero1(a);
            first::setwugong1(a,1,5);
            setHero1_5->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero1_5->pos();
            first::set_hero2(a);
            first::setwugong2(a,1,5);
            setHero1_5->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero1_5->pos();
            first::set_hero3(a);
            first::setwugong3(a,1,5);
            setHero1_5->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero1_5->x()&&a->getpos().y()==setHero1_5->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero1_5->x()&&b->getstartpos().y()==setHero1_5->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero1_5->x()&&c->getstartpos().y()==setHero1_5->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;


    });
    connect(setHero2_5,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero2_5->pos();
            first::set_hero1(a);
            first::setwugong1(a,2,5);
            setHero2_5->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero2_5->pos();
            first::set_hero2(a);
            first::setwugong2(a,2,5);
            setHero2_5->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero2_5->pos();
            first::set_hero3(a);
            first::setwugong3(a,2,5);
            setHero2_5->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero2_5->x()&&a->getpos().y()==setHero2_5->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero2_5->x()&&b->getstartpos().y()==setHero2_5->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero2_5->x()&&c->getstartpos().y()==setHero2_5->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero3_5,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero3_5->pos();
            first::set_hero1(a);
            first::setwugong1(a,3,5);
            setHero3_5->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero3_5->pos();
            first::set_hero2(a);
            first::setwugong2(a,3,5);
            setHero3_5->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero3_5->pos();
            first::set_hero3(a);
            first::setwugong3(a,3,5);
            setHero3_5->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero3_5->x()&&a->getpos().y()==setHero3_5->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero3_5->x()&&b->getstartpos().y()==setHero3_5->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero3_5->x()&&c->getstartpos().y()==setHero3_5->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    connect(setHero4_5,&button::clicked,this,[=](){
        if(F==1&&money>=70){
            QPoint a=setHero4_5->pos();
            first::set_hero1(a);
            first::setwugong1(a,4,5);
            setHero4_5->setEnabled(false);
            money-=70;
        }
        else if(F==2&&money>=100){
            QPoint a=setHero4_5->pos();
            first::set_hero2(a);
            first::setwugong2(a,4,5);
            setHero4_5->setEnabled(false);
            money-=100;
        }
        else if(F==3&&money>=120){
            QPoint a=setHero4_5->pos();
            first::set_hero3(a);
            first::setwugong3(a,4,5);
            setHero4_5->setEnabled(false);
            money-=120;
        }
        else if(F==-1){
            foreach(hero *a,hero_list){
                if(a->getpos().x()==setHero4_5->x()&&a->getpos().y()==setHero4_5->y()){
                    hero_list.removeOne(a);
                    break;
                }
            }
            foreach(wugong *b,wugong_list){
                if(b->getstartpos().x()==setHero4_5->x()&&b->getstartpos().y()==setHero4_5->y()){

                    wugong_list.removeOne(b);
                }
                break;
            }
            foreach(wugong *c,aoe_list){
                if(c->getstartpos().x()==setHero4_5->x()&&c->getstartpos().y()==setHero4_5->y()){
                    aoe_list.removeOne(c);
                }
            }
        }
        F=0;

    });
    //����Ӣ��
 //�������
    connect(_restart,&button::clicked,this,[=](){
        restart();
        guojing->setVisible(true);
        xiaolongnv->setVisible(true);
        huangyaohsi->setVisible(true);
        jingong->setVisible(true);
        shoubing->setVisible(true);
        jingong->setEnabled(true);
        update();
    });
    connect(jingong,&button::clicked,this,[=](){

        jingong->down();
        jingong->up();
        jingong->setEnabled(false);
        QTimer *dixitimer =new QTimer;
        connect(dixitimer,&QTimer::timeout,this,[=](){

            N++;
            first::shuaxin();
            foreach(wugong *a,wugong_list){
                int t=0;
                if(a->getavl()==true){
                    foreach(hero *b,hero_list){
                        if(a->getstartpos().x()==b->getpos().x()&&a->getstartpos().y()==b->getpos().y())
                            t=1;
                    }
                    if(t==0)
                        wugong_list.removeOne(a);
                }
            }
            foreach(wugong *a,aoe_list){
                int t=0;
                if(a->getavl()==true){
                    foreach(hero *b,hero_list){
                        if(a->getstartpos().x()==b->getpos().x()&&a->getstartpos().y()==b->getpos().y())
                            t=1;
                    }
                    if(t==0)
                        wugong_list.removeOne(a);
                }
            }
            if(jieshu==1||jieshu==2){//Ϊ������Ϸϴ������
                guojing->setVisible(false);
                xiaolongnv->setVisible(false);
                huangyaohsi->setVisible(false);
                jingong->setVisible(false);
                shoubing->setVisible(false);
                setHero1_1->setEnabled(true);
                setHero2_1->setEnabled(true);
                setHero3_1->setEnabled(true);
                setHero4_1->setEnabled(true);
                setHero1_2->setEnabled(true);
                setHero2_2->setEnabled(true);
                setHero3_2->setEnabled(true);
                setHero4_2->setEnabled(true);
                setHero1_3->setEnabled(true);
                setHero2_3->setEnabled(true);
                setHero3_3->setEnabled(true);
                setHero4_3->setEnabled(true);
                setHero1_4->setEnabled(true);
                setHero2_4->setEnabled(true);
                setHero3_4->setEnabled(true);
                setHero4_4->setEnabled(true);
                setHero1_5->setEnabled(true);
                setHero2_5->setEnabled(true);
                setHero3_5->setEnabled(true);
                setHero4_5->setEnabled(true);
                dixitimer->stop();
            }

            first::shadi();
            first::shengfu();
            if(N%50==0){
                first::yungong();

                for(int i=0;i<wugong_list.size();i++){
                    if(wugong_list[i]->getavl()==true)
                        qDebug()<<wugong_list[i]->getx()<<" "<<wugong_list[i]->gety();
                }

            }
            if(B<15){
            if(N%150==0){
                first::addenemy();

                N=0;
                B++;
            }
            }
            else if(B<45){
                if(N%50==0){
                    first::addenemy();
                    N=0;
                    B++;
                }
            }
            else if(B<70){
                if(N%10==0){
                    first::addenemy();
                    B++;
                }
            }

        });

        dixitimer->start(20);

    });


}
void first::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0, 0, QPixmap("://ditu.png"));
    if(jieshu==0){
    showmoney(&painter);
    foreach(hero *_hero,hero_list)
        _hero->draw(&painter);
    foreach(enemy *_enemy,enemy_list){
        if(_enemy->getcurrentpos().x()>=0&&_enemy->gethp()>0)
            _enemy->draw(&painter);
    }
    foreach(wugong *_wugong,wugong_list){
        if(_wugong->getavl()==false)
            _wugong->draw(&painter);
    }
    foreach(wugong *a,aoe_list){
        if(a->getavl()==false)
            a->draw(&painter);
    }
    }
    else if(jieshu==1){
        painter.drawPixmap(0,0,QPixmap("://lose.png"));

    }
    else if(jieshu==2)
        painter.drawPixmap(0,0,QPixmap("://win.png"));

}

void first::showmoney(QPainter *painter){
    painter->save();
    painter->setPen("#9900FF ");
    painter->setFont(QFont("Helvetica [Cronyx]", 20));
    painter->drawText(QRect(650,540,80,80),QString("money:%1").arg(money));
    painter->restore();
}//��ʾ��Ǯ
void first::set_hero1(QPoint pos){
    hero *a =new hero(pos,"://guojing.png");
    hero_list.push_back(a);
    update();
}
void first::set_hero2(QPoint pos){
    hero *a=new hero(pos,"://xiaolongnv.png");
    hero_list.push_back(a);
    update();
}
void first::set_hero3(QPoint pos){
    hero *a=new hero(pos,"://huangyaoshi.png");
    hero_list.push_back(a);
    update();
}
//����Ӣ��
void first::shuaxin(){
    update();


}
void first::shengfu(){
    foreach(enemy *a,enemy_list){
        if(a->getcurrentpos().x()==30){
            qDebug()<<"game over";
            emit lose();
            jieshu=1;
        }
    }
    if(B==70){
        if(enemy_list.size()==0){
            qDebug()<<"you win";
            emit victory();
            jieshu=2;
        }
    }
}//�ж�ʤ��
void first::restart(){
    foreach(hero *a,hero_list)
        hero_list.removeOne(a);
    foreach(wugong *a,wugong_list)
        wugong_list.removeOne(a);
    foreach(wugong *a,aoe_list)
        aoe_list.removeOne(a);
    foreach(enemy *a,enemy_list)
        enemy_list.removeOne(a);
    jieshu=0;
    N=1;
    B=1;
    money=150;


}

//���ӵ���
void first::addenemy(){
    int d=1+rand()%4;
    int x1,x2,y1,y2;
    x1=880;
    x2=30;
    switch(d){
    case 1:
        y1=y2=30;

        break;
    case 2:
        y1=y2=150;
        break;
    case 3:
        y1=y2=280;
        break;
    case 4:
        y1=y2=410;
        break;

    }
    enemy *a =new enemy(QPoint(x1,y1),QPoint(x2,y2),"://dongfangbubai.png");
    a->sethp(90);
    enemy_list.push_back(a);
    a->move();
    update();



}
void first::setwugong1(QPoint pos, int i, int j){

    wugong *a=new wugong(pos,QPoint(950,pos.y()),"://wuqi1.png",30,i,j);

    wugong_list.push_back(a);
}
void first::setwugong2(QPoint pos, int i, int j){

    wugong *a=new wugong(pos,QPoint(950,pos.y()),"://wuqi2.png",50,i,j);

    wugong_list.push_back(a);
}
void first::setwugong3(QPoint pos, int i, int j){
    wugong *a=new wugong(pos,QPoint(950,pos.y()),"://wuqi3.png",25,i,j);

    aoe_list.push_back(a);
}
void first::shadi(){
    foreach(wugong *a,wugong_list){
        if(a->getavl()==false){//�жϸ��书�Ƿ����˹���
            int b=a->getcurrentpos().y();
            int c=a->getcurrentpos().x();
            for(int i=0;i<enemy_list.size();i++){
                if(b==enemy_list[i]->getcurrentpos().y()){
                    if(enemy_list[i]->getcurrentpos().x()-c<10&&enemy_list[i]->getcurrentpos().x()-c>0){//�ж��书�Ĺ�����Χ���Ƿ����˵���
                        enemy_list[i]->sethp(enemy_list[i]->gethp()-a->getweili());
                        if(enemy_list[i]->gethp()<1){
                            enemy_list.removeAt(i);
                            money+=50;
                        }//�Ƴ��������ˣ���ý��
                        wugong *p=a;
                        a->movestop();
                        p->setcurrentpos(a->getstartpos());
                        p->canavl();

                        wugong_list.removeOne(a);

                        wugong_list.push_back(p);//�书�滻
                        break;
                    }
                }
            }
        }
    }
    foreach(wugong *a,aoe_list){
        if(a->getavl()==false){
            int b=a->getcurrentpos().y();
            int c=a->getcurrentpos().x();
            for(int i=0;i<enemy_list.size();i++){
                if(b==enemy_list[i]->getcurrentpos().y()){
                    if(enemy_list[i]->getcurrentpos().x()-c<10&&enemy_list[i]->getcurrentpos().x()-c>0){
                        enemy_list[i]->sethp(enemy_list[i]->gethp()-a->getweili());
                        if(enemy_list[i]->gethp()<1){
                            enemy_list.removeAt(i);
                            money+=50;
                        }
                        break;
                    }
                }
            }
        }
        if(a->getcurrentpos().x()==950){
            wugong *p=a;
            p->setcurrentpos(a->getstartpos());
            p->canavl();
            aoe_list.removeOne(a);
            aoe_list.push_back(p);
        }
    }
}
void first::yungong(){

    foreach(wugong *a,wugong_list){
        if(a->getavl()==true){//�ж�Ӣ���Ƿ�����˹�
            int b=a->getstartpos().y();
            int c=a->getstartpos().x();
            for(int i=0;i<enemy_list.size();i++){
                if(b==enemy_list.at(i)->getcurrentpos().y()){
                    if(enemy_list.at(i)->getcurrentpos().x()-c>40){//�ж�Ӣ��ǰ���Ƿ��е���
                        a->notavl();//Ӣ���˹���
                        a->move();
                        break;
                    }
                }
            }
        }
        if(a->getcurrentpos().x()==950){
            wugong *p=a;
            p->setcurrentpos(a->getstartpos());
            p->canavl();
            wugong_list.removeOne(a);
            wugong_list.push_back(p);

        }//���˱�ͬ·�ߵ�����Ӣ��ɱ������Ӣ����Ҫ�չ�
    }
    foreach(wugong *a,aoe_list){
        if(a->getavl()==true){

            int b=a->getstartpos().y();
            int c=a->getstartpos().x();
            for(int i=0;i<enemy_list.size();i++){
                if(b==enemy_list.at(i)->getcurrentpos().y()){
                    if(enemy_list.at(i)->getcurrentpos().x()-c>40){
                        a->notavl();
                        a->move();
                        break;

                    }
                }
            }
        }

        if(a->getcurrentpos().x()==950){
            wugong *p=a;
            p->setcurrentpos(a->getstartpos());
            p->canavl();
            wugong_list.removeOne(a);
            wugong_list.push_back(p);

        }
    }

}





