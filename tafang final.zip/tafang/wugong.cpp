#include "wugong.h"

wugong::wugong(QPoint startpos, QPoint targetpos, QString pix, double a, int _x, int _y):object(startpos,targetpos,pix){
    weili=a;
    x=_x;
    y=_y;
    avl=true;
}
void wugong::move(){
    QPropertyAnimation * animation =new QPropertyAnimation(this,"currentpos");
    animation->setDuration(5*(this->targetpos.x()-this->startpos.x()));
    animation->setStartValue(startpos);
    animation->setEndValue(targetpos);
    animation->start();
}
