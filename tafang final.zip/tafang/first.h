#ifndef FIRST_H
#define FIRST_H

#include <QMainWindow>
#include<QPainter>
#include"hero.h"
#include<QList>
#include"object.h"
#include"enemy.h"
#include"wugong.h"

class first : public QMainWindow
{
    Q_OBJECT
public:
    explicit first(QWidget *parent = nullptr);
    void set_hero1(QPoint pos);
    void set_hero2(QPoint pos);
    void set_hero3(QPoint pos);
    void shuaxin();
    void addenemy();
    void setwugong1(QPoint pos, int i,int j);
    void setwugong2(QPoint pos, int i, int j);
    void setwugong3(QPoint pos, int i, int j);
    void yungong();
    void shadi();
    void shengfu();
    void showmoney(QPainter *painter);
    void restart();
private:
    QList<hero *> hero_list;
    QList<enemy *> enemy_list;
    QList<wugong *>wugong_list;
    QList<wugong *>aoe_list;
    int jieshu=0;
    int F;
    int N=1;
    int B=1;
    int money=150;

signals:
    void lose();
    void victory();

public slots:
protected:
    void paintEvent(QPaintEvent *);
};

#endif // FIRST_H
