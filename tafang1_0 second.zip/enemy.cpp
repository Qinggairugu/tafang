#include "enemy.h"

enemy::enemy(QPoint startpos, QPoint targetpos, QString pix):object(startpos,targetpos,pix){

}
