#include "first.h"
#include"button.h"
#include<QPainter>
#include<QPoint>
#include<QPixmap>
#include<QTimer>
#include<QTime>
#include<math.h>
#include<QCoreApplication>
#include<QDebug>
first::first(QWidget *parent) : QMainWindow(parent)
{

    this->setFixedSize(960,640);
    button *huangyaohsi=new button("://huangyaoshi.png");
    huangyaohsi->setParent(this);
    huangyaohsi->move(300,500);
    QPushButton *setHero1_1= new QPushButton;
    setHero1_1->setParent(this);
    setHero1_1->setFixedSize(50,50);
    setHero1_1->setFlat(true);
    setHero1_1->move(30,30);
    QPushButton *setHero2_1= new QPushButton;
    setHero2_1->setParent(this);
    setHero2_1->setFixedSize(50,50);
    setHero2_1->setFlat(true);
    setHero2_1->move(30,150);
    QPushButton *setHero3_1= new QPushButton;
    setHero3_1->setParent(this);
    setHero3_1->setFixedSize(50,50);
    setHero3_1->setFlat(true);
    setHero3_1->move(30,280);
    QPushButton *setHero4_1= new QPushButton;
    setHero4_1->setParent(this);
    setHero4_1->setFixedSize(50,50);
    setHero4_1->setFlat(true);
    setHero4_1->move(30,410);
    button *jingong= new button(":/button3.png");
    jingong->setParent(this);
    jingong->move(800,500);

    connect(huangyaohsi,&button::clicked,this,[=](){
        huangyaohsi->down();
        huangyaohsi->up();
        connect(setHero1_1,&button::clicked,this,[=](){
            QPoint a=setHero1_1->pos();
            first::set_hero(a);
            first::setwugong(a,1,1);

        });
        connect(setHero2_1,&button::clicked,this,[=](){
            QPoint a=setHero2_1->pos();
            first::set_hero(a);
            first::setwugong(a,2,1);

        });

        connect(setHero3_1,&button::clicked,this,[=](){
            QPoint a=setHero3_1->pos();
            first::set_hero(a);
            first::setwugong(a,3,1);

        });

        connect(setHero4_1,&button::clicked,this,[=](){
            QPoint a=setHero4_1->pos();
            first::set_hero(a);
            first::setwugong(a,4,1);

        });


    });
    //�������
    connect(jingong,&button::clicked,this,[=](){
        jingong->down();
        jingong->up();
        jingong->setEnabled(false);
        QTimer *dixitimer =new QTimer;
        connect(dixitimer,&QTimer::timeout,this,[=](){
            first::addenemy();

        });

        dixitimer->start(2000);

    });
    QTimer *timer=new QTimer;
    connect(timer,&QTimer::timeout,this,[=](){
        first::shuaxin();


    });
    timer->start(20);

}
void first::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0, 0, QPixmap("://ditu.png"));
    foreach(hero *_hero,hero_list)
        _hero->draw(&painter);
    foreach(enemy *_enemy,enemy_list){
        if(_enemy->getcurrentpos().x()>=40&&_enemy->gethp()>40)
            _enemy->draw(&painter);
    }
    foreach(wugong *_wugong,wugong_list){
        _wugong->draw(&painter);
    }

}
//����Ӣ��
void first::set_hero(QPoint pos){
    hero *a =new hero(pos,"://huangyaoshi.png",100);
    hero_list.push_back(a);
    update();
}
void first::shuaxin(){
    update();
    yungong();
}
//���ӵ���
void first::addenemy(){
    int d=1+rand()%4;
    int x1,x2,y1,y2;
    x1=880;
    x2=30;
    switch(d){
    case 1:
        y1=y2=30;

        break;
    case 2:
        y1=y2=150;
        break;
    case 3:
        y1=y2=280;
        break;
    case 4:
        y1=y2=410;
        break;

    }
    enemy *a =new enemy(QPoint(x1,y1),QPoint(x2,y2),"://dongfangbubai.png");
    a->sethp(100);
    enemy_list.push_back(a);
    a->move();
    update();



}
void first::setwugong(QPoint pos, int i, int j){

    wugong *a=new wugong(pos,QPoint(960,pos.y()),"://bullet.png",100,i,j);

    wugong_list.push_back(a);
}
//void first::yungong(){
//    int n=-1;
//    int minx=1000;
//    foreach(wugong *a,wugong_list){
//        QTimer *jizhong =new QTimer;
//        jizhong->start(10);
//        int b=a->getcurrentpos().y();
//        int c=a->getcurrentpos().x();
//        for(int i=0;i<enemy_list.size();i++){
//            if(b==enemy_list.at(i)->getcurrentpos().y()){
//                if(enemy_list.at(i)->getcurrentpos().x()<minx){
//                    minx=enemy_list.at(i)->getcurrentpos().x();
//                    n=i;
//                }
//            }
//        }
//        if(n>=0){
//            a->move();
//            connect(jizhong,&QTimer::timeout,this,[=](){
//                if(abs(a->getcurrentpos().x()-enemy_list.at(n)->getcurrentpos().x())<20){
//                    wugong_list.removeOne(a);
//                    enemy_list.at(n)->sethp(enemy_list.at(n)->gethp()-a->getweili());

//                    if(enemy_list.at(n)->gethp()<1){
//                        enemy_list.removeAt(n);
//                        }
//                    jizhong->stop();

//                }

//            });
//            a->setcurrentpos(a->getstartpos());

//        }
//    }
//}

