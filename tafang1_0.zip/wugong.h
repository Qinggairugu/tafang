#ifndef WUGONG_H
#define WUGONG_H

#include <QObject>
#include "object.h"
class wugong : public object
{
public:
    wugong();
    wugong(QPoint startpos, QPoint targetpos, QString pix, double a, int _x, int _y);
    double getweili(){return weili;}
    void move();
    wugong operator =(wugong &p);
    int getx(){return y;}
    int gety(){return y;}
private:
    double weili;
    int x;
    int y;
};

#endif // WUGONG_H
